﻿using UnityEngine;
using System.Collections;
using System;
using Proto.gate;

[RequireComponent(typeof(pomeloBehaviour))]
public class PomeloManager : MonoBehaviour {

    [TextArea(3, 10)]
    public string HandShakeCache;

    public string host = "127.0.0.1";
    public int port = 3014;
    pomeloBehaviour client;
    public string uid = "1";


    public Action connectToConnector;
    public Action disconnectConnector;
    public Action connectGateFailed;

    void Awake()
    {
        client = GetComponent<pomeloBehaviour>();
        client.updateClientEvent += OnUpdateClient;
    }

    public void ConnectToGate()
    {
        client.connectEvent += OnConnectToGate;
        client.closeEvent += OnGateServerDisconnect;
        client.ConnectServer(host, port, Pomelo.DotNetClient.ClientProtocolType.NORMAL, HandShakeCache);
    }

    public void OnConnectToConnector()
    {
        client.closeEvent += OnServerDisconnect;


        this.HandShakeCache = client.GetHandShakeCache();

        if (connectToConnector != null)
        {
            connectToConnector.Invoke();
        }


        Debug.Log("Connector Connected");

    }
    public void OnConnectToGate()
    {
        Debug.Log("已连接上Gate服务器，现在发起Gate服务的操作");
        this.HandShakeCache = client.GetHandShakeCache();
        //gate logic can moveto logicclient
        gateHandler.queryEntry(uid, delegate (gateHandler.queryEntry_result result)
        {
            client.connectEvent -= OnConnectToGate;
            client.closeEvent -= OnGateServerDisconnect;

            client.CloseClient();

            if (result.code == 500)
            {
                //TODO
                Debug.Log("连接上Gate服务器后没有得到正确的返回");
            }


            if (result.code == 200)
            {
                Debug.Log("开始连接 Connector 服务器");
                client.connectEvent += OnConnectToConnector;
                client.ConnectServer(result.host, result.port, Pomelo.DotNetClient.ClientProtocolType.NORMAL, HandShakeCache);
            }

            //TODO other event
        });
        Debug.Log("Gate Connected");
    }


    private void OnUpdateClient()
    {
        Proto.Version.resetClient(client.pc);
    }

    private void OnServerDisconnect()
    {
        client.connectEvent -= OnConnectToConnector;
        client.closeEvent -= OnServerDisconnect;

        if (disconnectConnector != null) disconnectConnector.Invoke();

    }

    private void OnGateServerDisconnect()
    {
        client.connectEvent -= OnConnectToGate;
        client.closeEvent -= OnGateServerDisconnect;

        if (connectGateFailed != null) connectGateFailed.Invoke();

    }
}
