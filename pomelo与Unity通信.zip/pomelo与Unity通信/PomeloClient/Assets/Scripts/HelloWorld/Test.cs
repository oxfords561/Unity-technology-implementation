﻿using UnityEngine;
using System.Collections;
using Proto.connector;
using LitJson;

public class Test : MonoBehaviour
{

    private PomeloManager pomeloMgr;
    private string uid = "1";

    private void Awake()
    {
        //获取 pomelo管理
        pomeloMgr = GetComponent<PomeloManager>();
        //委托事件初始化
        pomeloMgr.connectToConnector += onConnectToConnector;
        pomeloMgr.disconnectConnector += onDisconnectConnector;
        pomeloMgr.connectGateFailed += onConnectGateFailed;
    }

    // Use this for initialization
    void Start()
    {
        //开始连接Gate服务器
        pomeloMgr.uid = uid;
        pomeloMgr.ConnectToGate();
    }

    /// <summary>
    /// 测试服务器
    /// </summary>
    public void TestOnClick()
    {
        //TODO 进行Connect服务器的连接
        //entryHandler.enter("用户名","房间名",delegate(JsonData result) 
        //{
        //    Debug.Log("成功连接Connector服务器");
        //    Debug.Log("Connector服务器返回的内容是 "+result["msg"]);
        //});
    }

    /// <summary>
    /// 连接上Gate服务器
    /// </summary>
    void onConnectToConnector()
    {
        Debug.Log("成功连接服务器");
    }

    /// <summary>
    /// 点击断开连接的时候
    /// </summary>
    void onDisconnectConnector()
    {
        Debug.Log("与服务器断开连接");
    }

    /// <summary>
    /// 连接到pomelo gate服务器失败的情况
    /// </summary>
    void onConnectGateFailed()
    {
        Debug.Log("与服务器连接失败");
    }
}
