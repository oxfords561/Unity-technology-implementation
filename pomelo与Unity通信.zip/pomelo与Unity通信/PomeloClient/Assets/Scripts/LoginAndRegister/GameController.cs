﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using Proto.connector;
using LitJson;

public class GameController : MonoBehaviour
{

    private GameObject loginPanel;
    private InputField userNameInput_login;
    private InputField passwordInput_login;
    private Button loginBtn;
    private Button registerBtn_login;

    private GameObject registerPanel;
    private InputField userNameInput_register;
    private InputField passwordInput_register;
    private InputField rePasswordInput_register;
    private Button registerBtn;
    private Button closeBtn;

    private PomeloManager pomeloMgr;
    private string uid = "1";

    void Awake()
    {
        //获取 pomelo管理
        pomeloMgr = GameObject.Find("pomelo_client").GetComponent<PomeloManager>();
        //委托事件初始化
        pomeloMgr.connectToConnector += onConnectToConnector;
        pomeloMgr.disconnectConnector += onDisconnectConnector;
        pomeloMgr.connectGateFailed += onConnectGateFailed;
    }

    void Start()
    {
        //初始化组件
        loginPanel = transform.Find("LoginPanel").gameObject;
        userNameInput_login = transform.Find("LoginPanel/UserNameInput").GetComponent<InputField>();
        passwordInput_login = transform.Find("LoginPanel/PasswordInput").GetComponent<InputField>();
        loginBtn = transform.Find("LoginPanel/LoginBtn").GetComponent<Button>();
        registerBtn_login = transform.Find("LoginPanel/RegisterBtn").GetComponent<Button>();

        registerPanel = transform.Find("RegisterPanel").gameObject;
        userNameInput_register = transform.Find("RegisterPanel/UserNameInput").GetComponent<InputField>();
        passwordInput_register = transform.Find("RegisterPanel/PasswordInput").GetComponent<InputField>();
        rePasswordInput_register = transform.Find("RegisterPanel/RePasswordInput").GetComponent<InputField>();
        registerBtn = transform.Find("RegisterPanel/RegisterBtn").GetComponent<Button>();
        closeBtn = transform.Find("RegisterPanel/CloseBtn").GetComponent<Button>();

        //绑定触发事件
        loginBtn.onClick.AddListener(LoginBtnClickEvent);
        registerBtn_login.onClick.AddListener(RegisterBtn_loginClickEvent);
        registerBtn.onClick.AddListener(RegisterBtnClickEvent);
        closeBtn.onClick.AddListener(CLoseBtnClickEvent);

        //开始连接Gate服务器
        pomeloMgr.uid = uid;
        pomeloMgr.ConnectToGate();
    }

    /// <summary>
    /// 点击登录
    /// </summary>
    void LoginBtnClickEvent()
    {
        entryHandler.login(userNameInput_login.text, passwordInput_login.text, delegate (JsonData result)
        {
            Debug.Log(result["msg"]);
        });
    }

    void RegisterBtn_loginClickEvent()
    {
        loginPanel.SetActive(false);
        registerPanel.SetActive(true);
    }

    void RegisterBtnClickEvent()
    {
        entryHandler.register(userNameInput_register.text, passwordInput_register.text, delegate (JsonData result)
        {
            Debug.Log(result["msg"]);
        });
    }

    void CLoseBtnClickEvent()
    {
        loginPanel.SetActive(true);
        registerPanel.SetActive(false);
    }

    /// <summary>
    /// 连接上Gate服务器
    /// </summary>
    void onConnectToConnector()
    {
        Debug.Log("成功连接Connector服务器,然后发起Connector服务");
    }

    /// <summary>
    /// 点击断开连接的时候
    /// </summary>
    void onDisconnectConnector()
    {
        Debug.Log("与Gate服务器断开连接");
    }

    /// <summary>
    /// 连接到pomelo gate服务器失败的情况
    /// </summary>
    void onConnectGateFailed()
    {
        Debug.Log("与Gate服务器连接失败");
    }
}
