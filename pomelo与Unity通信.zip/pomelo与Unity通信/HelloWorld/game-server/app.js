var pomelo = require('pomelo');

/**
 * Init app for client.
 */
var app = pomelo.createApp();
app.set('name', 'HelloWorld');

// app configuration 添加Connector 服务器模块
app.configure('production|development', 'connector', function(){
  app.set('connectorConfig',
    {
      connector : pomelo.connectors.hybridconnector,
      heartbeat : 3,
      useDict : true,
      useProtobuf : true
    });
});

//添加gate服务器模块
app.configure('production|development', 'gate', function(){
	app.set('connectorConfig',
		{
			connector : pomelo.connectors.hybridconnector,
			useProtobuf : true,
			useDict:true
		});
});

//加载数据库配置信息
app.loadConfig('mysql', app.getBase() + '/../shared/config/mysql.json');
// 配置数据库 使用的服务器 Connector和master dbclient对象初始化到app里面 方便调用
app.configure('production|development', 'connector|master', function () {
  var dbclient = require('./app/dao/mysql/mysql').init(app);
  app.set('dbclient', dbclient);
  // app.load(pomelo.sync, {path:__dirname + '/app/dao/mapping', dbclient: dbclient});
  //下面这个不清楚用法 TODO
  //app.use(sync, {sync: {path: __dirname + '/app/dao/mapping', dbclient: dbclient}});
});

// start app
app.start();

process.on('uncaughtException', function (err) {
  console.error(' Caught exception: ' + err.stack);
});
