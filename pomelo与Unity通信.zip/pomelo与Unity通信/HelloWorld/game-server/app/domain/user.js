
var User = function(opts){
    this.id = opts.id;
    this.name = opts.name;
    this.password = opts.password;
}

module.exports = User;