var pomelo = require('pomelo');
var utils = require('../util/utils');
var User = require('../domain/user');
var userDao = module.exports;

/**
 * Get user data by username.
 * @param {String} username
 * @param {String} passwd
 * @param {function} cb
 */
userDao.getUserInfo = function (username, passwd, cb) {
	var sql = 'select * from	User where name = ?';
	var args = [username];

	pomelo.app.get('dbclient').query(sql,args,function(err, res) {
		if(err !== null) {
				utils.invokeCallback(cb, err, null);
		} else {
			var userId = 0;
			if (!!res && res.length === 1) {
				var rs = res[0];
				userId = rs.id;
				rs.uid = rs.id;
				utils.invokeCallback(cb,null, rs);
			} else {
				utils.invokeCallback(cb, '查询不到', {uid:0, username: username});
			}
		}
	});
};

/**
 * Create a new user
 * @param (String) username
 * @param {String} password
 * @param {String} from Register source
 * @param {function} cb Call back function.
 */
userDao.createUser = function (username, password, cb){
	var sql = 'insert into User (name,password) values(?,?)';
	var args = [username, password];
	pomelo.app.get('dbclient').insert(sql, args, function(err,res){
		if(err !== null){
			utils.invokeCallback(cb, {code: err.number, msg: err.message}, null);
		} else {
			var user = new User({id: res.insertId, name: username, password: password});
			utils.invokeCallback(cb, null, user);
		}
	});
};