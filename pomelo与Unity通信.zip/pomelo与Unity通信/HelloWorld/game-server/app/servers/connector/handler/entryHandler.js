var userDao = require('../../../dao/userDao');


module.exports = function(app) {
  return new Handler(app);
};

var Handler = function(app) {
  this.app = app;
};

/**
 * 登录模块
 *
 * @param  {Object}   msg     request message
 * @param  {Object}   session current session object
 * @param  {Function} next    next step callback
 * @return {Void}
 */
Handler.prototype.login = function(msg, session, next) {
	console.log('成功连接Connector服务器');
	console.log('客户端传递过来的数据是 ： '+msg.username+' '+msg.password);
	//进行用户名的数据库查询
	userDao.getUserInfo(msg.username,msg.password,function(err,rs){
		if(err){
			console.log('用户名数据库查询出错,不存在用户');
			return;
		}else{
			console.log('当前用户可以登录');
			console.log('用户信息为： '+rs.id+' '+rs.name+' '+rs.password);
		}
	});
  next(null, {code: 200, msg: 'game server is ok.'});
};

/*
注册模块
*/
Handler.prototype.register = function(msg,session,next){
	console.log('客户端传递过来的数据是 ： '+msg.username+' '+msg.password);
	userDao.createUser(msg.username,msg.password,function(err,user){
		if(err){
			console.log('注册用户失败');
			return;
		}else{
			console.log('注册用户成功');
			console.log('注册的用户的信息 ：'+user.id+' '+user.name);
		}
	});
};

/**
 * Publish route for mqtt connector.
 *
 * @param  {Object}   msg     request message
 * @param  {Object}   session current session object
 * @param  {Function} next    next step callback
 * @return {Void}
 */
Handler.prototype.publish = function(msg, session, next) {
	var result = {
		topic: 'publish',
		payload: JSON.stringify({code: 200, msg: 'publish message is ok.'})
	};
  next(null, result);
};

/**
 * Subscribe route for mqtt connector.
 *
 * @param  {Object}   msg     request message
 * @param  {Object}   session current session object
 * @param  {Function} next    next step callback
 * @return {Void}
 */
Handler.prototype.subscribe = function(msg, session, next) {
	var result = {
		topic: 'subscribe',
		payload: JSON.stringify({code: 200, msg: 'subscribe message is ok.'})
	};
  next(null, result);
};
